# Case: Testing comments

This repository simulates the following situations:

1. A valid (uncommented) reference to the test framework is inserted in a certain commit (it should be detected as an adoption event - the first valid referente to the test framework).
2. This reference is commented in the next commit (it should be detected as a removal event - the last reference to the test framework)