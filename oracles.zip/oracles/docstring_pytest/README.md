# Case: Reference to the framework in a docstring

This repository simulates one where the referece to a test framework is within a docstring. It should be ignored.