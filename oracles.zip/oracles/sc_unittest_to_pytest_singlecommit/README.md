# Simple Case Oracle
## Pytest project migrated in one commit

This repository simulates one that uses the python test framework "pytest".

#### Running tests

```sh
pytest
```