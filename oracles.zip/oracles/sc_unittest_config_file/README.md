# Simple Case

This repository simulates one with a reference to the test framework in a config file.
