# Simple Case Oracle

This repository simulates one that uses two test frameworks.

#### Running tests

```sh
pytest
```