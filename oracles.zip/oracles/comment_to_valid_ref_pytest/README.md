# Case: Testing comments

This repository simulates the following situations:

1. An invalid (commented) reference to the test framework is inserted in a certain commit (it should not be detected).
2. This reference is uncommented in the next commit (it should be detected as an adoption event)