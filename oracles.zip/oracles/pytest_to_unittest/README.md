# Case: reverse migration
### Running tests
```sh
$ python -m unittest discover
```