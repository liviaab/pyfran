# Simple Case Oracle
## Pytest project migrated in multiple commits

This repository simulates one that uses the python test framework "unittest".

#### Running tests

```sh
pytest
```