# Simple Case Oracle
## Pytest project since the beginning

This repository simulates one that uses the python test framework "pytest" since the beginning.

### Running tests
```sh
$ pytest
```