# Case: Migrating test frameworks in multiple commits

This repository simulates one that uses the python test framework "pytest".

#### Running tests

```sh
pytest
```