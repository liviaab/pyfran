# Case: Migrating test frameworks in a single commit

This repository simulates one that uses the python test framework "pytest".

#### Running tests

```sh
pytest
```